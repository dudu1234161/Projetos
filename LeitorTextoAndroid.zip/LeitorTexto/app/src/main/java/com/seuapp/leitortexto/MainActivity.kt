package com.seuapp.leitortexto

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import java.util.*
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var textToSpeech: TextToSpeech
    private lateinit var imageCapture: ImageCapture

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        startCamera()

        textToSpeech = TextToSpeech(this) {
            if (it != TextToSpeech.ERROR) {
                textToSpeech.language = Locale("pt", "BR")
            }
        }

        findViewById<Button>(R.id.captureButton).setOnClickListener {
            captureAndRecognizeText()
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder().build()
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureAndRecognizeText() {
        val photoFile = File.createTempFile("temp", ".jpg", cacheDir)
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture.takePicture(outputOptions, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    val image = InputImage.fromFilePath(this@MainActivity, photoFile.toURI())
                    val recognizer = TextRecognition.getClient()
                    recognizer.process(image)
                        .addOnSuccessListener { visionText ->
                            val texto = visionText.text
                            Toast.makeText(applicationContext, texto, Toast.LENGTH_LONG).show()
                            textToSpeech.speak(texto, TextToSpeech.QUEUE_FLUSH, null, null)
                        }
                        .addOnFailureListener {
                            Toast.makeText(applicationContext, "Erro ao reconhecer texto", Toast.LENGTH_SHORT).show()
                        }
                }

                override fun onError(exception: ImageCaptureException) {
                    Toast.makeText(applicationContext, "Erro ao capturar imagem", Toast.LENGTH_SHORT).show()
                }
            })
    }

    override fun onDestroy() {
        textToSpeech.stop()
        textToSpeech.shutdown()
        super.onDestroy()
    }
}